-- ============================================================
-- LedgerAI — Full Database Schema
-- Project: ledgerai (ap-south-1, Mumbai)
-- Run this in: Supabase Dashboard > SQL Editor
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ============================================================
-- TABLE: business_info
-- Stores company/business details and accounting period
-- ============================================================
create table if not exists business_info (
  id            uuid primary key default uuid_generate_v4(),
  name          text not null default 'My Company',
  registration  text,
  address       text,
  period_start  date,
  period_end    date,
  fy_label      text default 'FY 2024-25',
  currency      text default 'INR',
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ============================================================
-- TABLE: parties
-- Debtors (customers) and creditors (vendors)
-- ============================================================
create table if not exists parties (
  id            uuid primary key default uuid_generate_v4(),
  name          text not null,
  party_type    text not null check (party_type in ('debtor','creditor')),
  gstin         text,
  pan           text,
  address       text,
  email         text,
  phone         text,
  balance       numeric(15,2) default 0,
  currency      text default 'INR',
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

create index if not exists idx_parties_name on parties(name);
create index if not exists idx_parties_type on parties(party_type);

-- ============================================================
-- TABLE: journals
-- Journal entry headers (double-entry bookkeeping)
-- ============================================================
create table if not exists journals (
  id            uuid primary key default uuid_generate_v4(),
  ref           text not null unique,              -- JE-001, JE-002 ...
  date          date not null,
  narration     text,
  currency      text default 'INR',
  status        text default 'posted' check (status in ('draft','posted','reversed')),
  reversed_by   uuid references journals(id),
  created_at    timestamptz default now()
);

create index if not exists idx_journals_date on journals(date);
create index if not exists idx_journals_ref  on journals(ref);

-- ============================================================
-- TABLE: journal_lines
-- Individual debit/credit lines per journal entry
-- ============================================================
create table if not exists journal_lines (
  id            uuid primary key default uuid_generate_v4(),
  journal_id    uuid not null references journals(id) on delete cascade,
  account_code  text not null,
  account_name  text,
  debit         numeric(15,2) default 0,
  credit        numeric(15,2) default 0,
  party_id      uuid references parties(id),
  party_name    text,
  party_type    text,
  narration     text,
  created_at    timestamptz default now(),
  constraint    chk_debit_credit check (
    (debit >= 0 and credit = 0) or (credit >= 0 and debit = 0)
  )
);

create index if not exists idx_jlines_journal  on journal_lines(journal_id);
create index if not exists idx_jlines_account  on journal_lines(account_code);
create index if not exists idx_jlines_party    on journal_lines(party_id);

-- ============================================================
-- TABLE: documents
-- Uploaded invoice/bill/receipt metadata
-- ============================================================
create table if not exists documents (
  id            uuid primary key default uuid_generate_v4(),
  file_name     text not null,
  doc_type      text,                              -- Sales Invoice, Purchase Bill, etc.
  party_name    text,
  party_id      uuid references parties(id),
  invoice_no    text,
  doc_date      date,
  amount        numeric(15,2),
  tax_amount    numeric(15,2) default 0,
  cgst          numeric(15,2) default 0,
  sgst          numeric(15,2) default 0,
  igst          numeric(15,2) default 0,
  tax_rate      numeric(5,2)  default 0,
  currency      text default 'INR',
  journal_id    uuid references journals(id),
  status        text default 'pending' check (status in ('pending','posted','error')),
  confidence    numeric(3,2),
  ai_raw        jsonb,                             -- raw Claude response
  created_at    timestamptz default now()
);

create index if not exists idx_docs_party   on documents(party_name);
create index if not exists idx_docs_date    on documents(doc_date);
create index if not exists idx_docs_status  on documents(status);

-- ============================================================
-- TABLE: anomalies
-- AI-detected flags on documents and journal entries
-- ============================================================
create table if not exists anomalies (
  id            uuid primary key default uuid_generate_v4(),
  document_id   uuid references documents(id),
  journal_id    uuid references journals(id),
  flag_type     text,                              -- duplicate, large_amount, missing_field, etc.
  description   text,
  severity      text default 'warning' check (severity in ('info','warning','critical')),
  resolved      boolean default false,
  resolved_at   timestamptz,
  resolved_by   text,
  created_at    timestamptz default now()
);

create index if not exists idx_anomalies_resolved on anomalies(resolved);

-- ============================================================
-- TABLE: audit_log
-- Immutable log of all changes (IFRS compliance)
-- ============================================================
create table if not exists audit_log (
  id            uuid primary key default uuid_generate_v4(),
  table_name    text not null,
  record_id     uuid,
  action        text not null check (action in ('INSERT','UPDATE','DELETE')),
  old_data      jsonb,
  new_data      jsonb,
  user_agent    text,
  created_at    timestamptz default now()
);

create index if not exists idx_audit_table  on audit_log(table_name);
create index if not exists idx_audit_action on audit_log(action);
create index if not exists idx_audit_time   on audit_log(created_at);

-- ============================================================
-- ROW LEVEL SECURITY
-- All tables are private by default (no public access)
-- ============================================================
alter table business_info  enable row level security;
alter table parties        enable row level security;
alter table journals       enable row level security;
alter table journal_lines  enable row level security;
alter table documents      enable row level security;
alter table anomalies      enable row level security;
alter table audit_log      enable row level security;

-- Service role (used by Edge Functions) bypasses RLS — no policies needed.
-- If you add auth later, add policies like:
-- create policy "owner_only" on journals for all using (auth.uid() = owner_id);

-- ============================================================
-- FUNCTION: update_updated_at()
-- Auto-update updated_at timestamp on row change
-- ============================================================
create or replace function update_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_business_info_updated
  before update on business_info
  for each row execute function update_updated_at();

create trigger trg_parties_updated
  before update on parties
  for each row execute function update_updated_at();

-- ============================================================
-- FUNCTION: party_balance_update()
-- Keeps parties.balance in sync when journal_lines change
-- ============================================================
create or replace function party_balance_update()
returns trigger language plpgsql as $$
begin
  if TG_OP = 'INSERT' or TG_OP = 'UPDATE' then
    update parties
    set balance = (
      select coalesce(sum(debit), 0) - coalesce(sum(credit), 0)
      from journal_lines
      where party_id = new.party_id
    )
    where id = new.party_id;
  end if;
  return new;
end;
$$;

create trigger trg_party_balance
  after insert or update on journal_lines
  for each row
  when (new.party_id is not null)
  execute function party_balance_update();

-- ============================================================
-- SEED: Default business info row
-- ============================================================
insert into business_info (name, registration, fy_label, currency)
values ('My Company', '', 'FY 2025-26', 'INR')
on conflict do nothing;

-- ============================================================
-- DONE
-- Run: supabase secrets set ANTHROPIC_API_KEY=sk-ant-... --project-ref wvzvtthwzlufbuyqknou
-- ============================================================
