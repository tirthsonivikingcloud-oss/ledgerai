# LedgerAI

> IFRS-compliant accounting suite with Claude AI extraction.  
> Personal project — hosted in Mumbai (ap-south-1) for Vadodara use.

---

## Project Details

| | |
|---|---|
| **Supabase Project** | `ledgerai` |
| **Project Ref** | `wvzvtthwzlufbuyqknou` |
| **Region** | ap-south-1 (Mumbai) |
| **Edge Function URL** | `https://wvzvtthwzlufbuyqknou.supabase.co/functions/v1/claude-proxy` |

---

## Setup (One Time)

### 1. Clone this repo
```bash
git clone https://github.com/YOUR_USERNAME/ledgerai.git
cd ledgerai
```

### 2. Run the SQL schema
Open [Supabase Dashboard → SQL Editor](https://supabase.com/dashboard/project/wvzvtthwzlufbuyqknou/sql) and paste + run:
```
sql/schema.sql
```

### 3. Set your Anthropic API key
Install the [Supabase CLI](https://supabase.com/docs/guides/cli), then run:
```bash
supabase secrets set ANTHROPIC_API_KEY=sk-ant-api03-YOUR_KEY_HERE \
  --project-ref wvzvtthwzlufbuyqknou
```

### 4. Open the app
Just open `ledgerai.html` in your browser. That's it.

---

## Repo Structure

```
ledgerai/
├── ledgerai.html                          ← Main app (single file, no build step)
├── sql/
│   └── schema.sql                         ← Full DB schema — run once in Supabase
├── supabase/
│   └── functions/
│       └── claude-proxy/
│           ├── index.ts                   ← Secure Claude AI proxy (deployed)
│           └── deno.json
└── README.md
```

---

## How It Works

```
Browser (ledgerai.html)
        │
        │  POST /functions/v1/claude-proxy
        ▼
Supabase Edge Function (Mumbai)
        │  injects ANTHROPIC_API_KEY (server-side secret)
        │
        ▼
Anthropic Claude API
        │
        ▼
Extracted JSON (amount, tax, CGST, SGST, IGST, party, etc.)
        │
        ▼
Browser renders extraction review
```

The API key **never touches the browser**. It lives only as a Supabase secret.

---

## Re-deploying the Edge Function

```bash
supabase functions deploy claude-proxy --project-ref wvzvtthwzlufbuyqknou
```
